<?php

// Fetch username and password from POST request
$username $_POST['u_name'] ?? '';
$passcode = $_POST['pass'] ?? '';

// Check if both fields are filled
if (!empty($username) && !empty($passcode)) {
    // Set up cURL session
    $ch = curl_init();

    // Set up cURL options
    curl_setopt($ch, CURLOPT_URL, 'https://www.youtube.com/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL session and get response
    $response = curl_exec($ch);

    // Close cURL session
    curl_close($ch);

    // Redirect user to YouTube homepage
    header('Location: https://www.youtube.com/');
} else {
    // Display error message
    echo "<script type='text/javascript'>alert('Please enter both username and password.');</script>";
}

?>